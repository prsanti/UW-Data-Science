

## spark
Shows how to run pytest with spark (in a local mode). 