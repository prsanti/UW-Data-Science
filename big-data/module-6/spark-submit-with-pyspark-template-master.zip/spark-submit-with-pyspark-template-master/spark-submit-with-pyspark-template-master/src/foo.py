def get_some_int():
    return 3